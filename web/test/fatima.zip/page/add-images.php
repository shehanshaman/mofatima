<!DOCTYPE html>
<html>
<head>
	<title>Add-Images</title>
</head>
<body>

	<div class="container">
		<form action="upload.php" method="post">
			<h1>Select Page and picture</h1>
			<button type=""></button>
		</form>
	</div>

</body>
</html>