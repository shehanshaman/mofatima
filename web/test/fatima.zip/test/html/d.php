<?php 
	echo date("Y/m/d h:i:sa");
 ?>