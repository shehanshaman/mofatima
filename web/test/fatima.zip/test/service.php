<!DOCTYPE html>
<html>
<head>
	<link rel="shortcut icon" type="image/x-icon" href="img/icons/favicon.ico" />
	<title>Fatima Church Dippitigoda</title>
	<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="stylesheet" type="text/css" href="css/service.css">
</head>
<body style="background-image: url(img/home/background/back0.jpg);">
	<div class = "wrapper">
		<?php include("html/top-bar.html"); ?>
		<div class="intro">
			<div class="intro_txt" style="background-image: url(img/services/intro.jpg);">
				<h1>SERVICES</h1>
			</div><!-- intro_txt -->
		</div><!-- intro -->

			
		<div class="welcome">
			<div class="welcome_txt">
				<h2>OUR SHEDULE</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</p>
			</div>
			<div class="new">
			<p>
			<?php
				$im_shedule = '../test/Data/shedule/shedule-text.txt';
				$shedule_text = file_get_contents($im_shedule);

				if(!trim($shedule_text)==''){
					echo "<i class='fa fa-exclamation' aria-hidden='true'></i>";
				}
			?>
			<?php include 'Data/shedule/shedule-head.txt'; ?>
			<?php include 'Data/shedule/shedule-text.txt'; ?></p>
		</div>
		</div><!-- welcome -->
		
	</div><!-- wrapper -->
	<div class="wrapper clearfix" >
		<?php include("html/botom-bar.php"); ?>
	</div>
	
</body>
</html>