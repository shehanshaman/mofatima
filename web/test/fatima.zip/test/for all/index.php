<?php 
	header("Location: ../html/");
 ?>